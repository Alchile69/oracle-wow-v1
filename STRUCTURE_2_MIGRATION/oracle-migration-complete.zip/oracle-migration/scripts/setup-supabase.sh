#!/bin/bash
# Oracle Portfolio - Script de configuration Supabase
# Alternative à Firebase pour base de données

set -e

echo "🗄️ CONFIGURATION SUPABASE"
echo "========================="

# Couleurs pour les logs
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

log_step() {
    echo -e "${BLUE}[STEP]${NC} $1"
}

# Vérification des prérequis
check_prerequisites() {
    log_step "1/6 - Vérification des prérequis"
    
    if ! command -v npm &> /dev/null; then
        log_error "npm non installé"
        exit 1
    fi
    
    log_info "✅ Prérequis validés"
}

# Installation de Supabase CLI
install_supabase_cli() {
    log_step "2/6 - Installation de Supabase CLI"
    
    if ! command -v supabase &> /dev/null; then
        log_info "Installation de Supabase CLI..."
        npm install -g supabase
    else
        log_info "Supabase CLI déjà installé"
    fi
    
    log_info "✅ Supabase CLI prêt"
}

# Initialisation du projet Supabase
init_supabase_project() {
    log_step "3/6 - Initialisation du projet Supabase"
    
    if [ ! -f "supabase/config.toml" ]; then
        log_info "Initialisation du projet Supabase..."
        supabase init
    else
        log_info "Projet Supabase déjà initialisé"
    fi
    
    log_info "✅ Projet Supabase initialisé"
}

# Configuration des tables
setup_database_schema() {
    log_step "4/6 - Configuration du schéma de base de données"
    
    # Création du dossier migrations s'il n'existe pas
    mkdir -p supabase/migrations
    
    # Création de la migration initiale
    log_info "Création du schéma Oracle Portfolio..."
    
    MIGRATION_FILE="supabase/migrations/$(date +%Y%m%d%H%M%S)_oracle_portfolio_schema.sql"
    
    cat > "$MIGRATION_FILE" << 'EOF'
-- Oracle Portfolio - Schéma de base de données
-- Tables pour l'analyse financière et la gestion de portefeuille

-- Extension pour UUID
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Table des utilisateurs (étend auth.users)
CREATE TABLE public.profiles (
    id UUID REFERENCES auth.users ON DELETE CASCADE,
    username TEXT UNIQUE,
    full_name TEXT,
    avatar_url TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    PRIMARY KEY (id)
);

-- Table des portefeuilles
CREATE TABLE public.portfolios (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    description TEXT,
    initial_value DECIMAL(15,2) DEFAULT 0,
    current_value DECIMAL(15,2) DEFAULT 0,
    currency TEXT DEFAULT 'EUR',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Table des actifs
CREATE TABLE public.assets (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    symbol TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    asset_type TEXT NOT NULL, -- 'stock', 'bond', 'commodity', 'crypto', 'fund'
    sector TEXT,
    country TEXT,
    currency TEXT DEFAULT 'EUR',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Table des positions de portefeuille
CREATE TABLE public.portfolio_positions (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    portfolio_id UUID REFERENCES public.portfolios(id) ON DELETE CASCADE,
    asset_id UUID REFERENCES public.assets(id) ON DELETE CASCADE,
    quantity DECIMAL(15,6) NOT NULL,
    average_cost DECIMAL(15,4) NOT NULL,
    current_price DECIMAL(15,4),
    market_value DECIMAL(15,2),
    weight_percent DECIMAL(5,2),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(portfolio_id, asset_id)
);

-- Table des prix historiques
CREATE TABLE public.price_history (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    asset_id UUID REFERENCES public.assets(id) ON DELETE CASCADE,
    date DATE NOT NULL,
    open_price DECIMAL(15,4),
    high_price DECIMAL(15,4),
    low_price DECIMAL(15,4),
    close_price DECIMAL(15,4) NOT NULL,
    volume BIGINT,
    adjusted_close DECIMAL(15,4),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(asset_id, date)
);

-- Table des analyses de régimes économiques
CREATE TABLE public.economic_regimes (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    country TEXT NOT NULL,
    analysis_date DATE NOT NULL,
    regime TEXT NOT NULL, -- 'EXPANSION', 'TRANSITION', 'RECESSION', 'STAGNATION'
    confidence DECIMAL(5,2) NOT NULL,
    economic_score DECIMAL(8,2),
    indicators JSONB,
    allocation_recommendations JSONB,
    risk_level TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(country, analysis_date)
);

-- Table des backtests
CREATE TABLE public.backtests (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    strategy TEXT NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    initial_capital DECIMAL(15,2) NOT NULL,
    final_capital DECIMAL(15,2),
    total_return DECIMAL(8,4),
    annualized_return DECIMAL(8,4),
    volatility DECIMAL(8,4),
    sharpe_ratio DECIMAL(8,4),
    max_drawdown DECIMAL(8,4),
    results JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Table des analyses de performance
CREATE TABLE public.performance_analyses (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    portfolio_id UUID REFERENCES public.portfolios(id) ON DELETE CASCADE,
    analysis_date DATE NOT NULL,
    period_type TEXT NOT NULL, -- 'daily', 'weekly', 'monthly', 'quarterly', 'yearly'
    return_metrics JSONB,
    risk_metrics JSONB,
    relative_metrics JSONB,
    performance_grade TEXT,
    recommendations TEXT[],
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(portfolio_id, analysis_date, period_type)
);

-- Table des logs d'activité
CREATE TABLE public.activity_logs (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
    action TEXT NOT NULL,
    entity_type TEXT, -- 'portfolio', 'backtest', 'analysis'
    entity_id UUID,
    details JSONB,
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Index pour les performances
CREATE INDEX idx_portfolios_user_id ON public.portfolios(user_id);
CREATE INDEX idx_portfolio_positions_portfolio_id ON public.portfolio_positions(portfolio_id);
CREATE INDEX idx_price_history_asset_date ON public.price_history(asset_id, date DESC);
CREATE INDEX idx_economic_regimes_country_date ON public.economic_regimes(country, analysis_date DESC);
CREATE INDEX idx_backtests_user_id ON public.backtests(user_id);
CREATE INDEX idx_performance_analyses_portfolio_date ON public.performance_analyses(portfolio_id, analysis_date DESC);
CREATE INDEX idx_activity_logs_user_date ON public.activity_logs(user_id, created_at DESC);

-- Fonctions de mise à jour automatique des timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Triggers pour les timestamps
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_portfolios_updated_at BEFORE UPDATE ON public.portfolios FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_portfolio_positions_updated_at BEFORE UPDATE ON public.portfolio_positions FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_backtests_updated_at BEFORE UPDATE ON public.backtests FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Politiques de sécurité RLS (Row Level Security)
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.portfolios ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.portfolio_positions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.backtests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.performance_analyses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.activity_logs ENABLE ROW LEVEL SECURITY;

-- Politiques pour les profils
CREATE POLICY "Users can view own profile" ON public.profiles FOR SELECT USING (auth.uid() = id);
CREATE POLICY "Users can update own profile" ON public.profiles FOR UPDATE USING (auth.uid() = id);

-- Politiques pour les portefeuilles
CREATE POLICY "Users can view own portfolios" ON public.portfolios FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own portfolios" ON public.portfolios FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own portfolios" ON public.portfolios FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own portfolios" ON public.portfolios FOR DELETE USING (auth.uid() = user_id);

-- Politiques pour les positions
CREATE POLICY "Users can view own portfolio positions" ON public.portfolio_positions FOR SELECT 
USING (EXISTS (SELECT 1 FROM public.portfolios WHERE id = portfolio_id AND user_id = auth.uid()));

-- Politiques pour les backtests
CREATE POLICY "Users can view own backtests" ON public.backtests FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own backtests" ON public.backtests FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own backtests" ON public.backtests FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own backtests" ON public.backtests FOR DELETE USING (auth.uid() = user_id);

-- Données de test
INSERT INTO public.assets (symbol, name, asset_type, sector, country) VALUES
('SPY', 'SPDR S&P 500 ETF', 'fund', 'Diversified', 'US'),
('BND', 'Vanguard Total Bond Market ETF', 'fund', 'Bonds', 'US'),
('GLD', 'SPDR Gold Shares', 'commodity', 'Precious Metals', 'US'),
('VTI', 'Vanguard Total Stock Market ETF', 'fund', 'Diversified', 'US'),
('VXUS', 'Vanguard Total International Stock ETF', 'fund', 'International', 'US');

-- Insertion d'une analyse de régime économique exemple
INSERT INTO public.economic_regimes (country, analysis_date, regime, confidence, economic_score, indicators, allocation_recommendations, risk_level) VALUES
('FR', CURRENT_DATE, 'TRANSITION', 72.8, 65.3, 
'{"pmi_manufacturing": 52.3, "unemployment_rate": 7.2, "gdp_growth": 1.8, "inflation_rate": 2.1}',
'{"equities": 50.0, "bonds": 35.0, "commodities": 10.0, "cash": 5.0}',
'MODERATE_HIGH');
EOF
    
    log_info "✅ Schéma de base de données créé: $MIGRATION_FILE"
}

# Configuration des variables d'environnement
setup_environment_variables() {
    log_step "5/6 - Configuration des variables d'environnement"
    
    # Mise à jour du .env avec les variables Supabase
    log_info "Configuration des variables Supabase..."
    
    if [ ! -f ".env" ]; then
        touch .env
    fi
    
    # Ajout des variables Supabase au .env
    cat >> .env << 'EOF'

# Supabase Configuration
VITE_SUPABASE_URL=your_supabase_project_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key
EOF
    
    # Mise à jour du .env.example
    cat >> .env.example << 'EOF'

# Supabase Configuration
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key
EOF
    
    log_info "✅ Variables d'environnement configurées"
}

# Installation des dépendances Supabase
install_supabase_dependencies() {
    log_step "6/6 - Installation des dépendances Supabase"
    
    log_info "Installation du client Supabase..."
    npm install @supabase/supabase-js
    
    # Installation des dépendances pour l'authentification
    npm install @supabase/auth-helpers-react
    
    log_info "✅ Dépendances Supabase installées"
}

# Création des fichiers de configuration
create_supabase_config() {
    log_info "Création des fichiers de configuration Supabase..."
    
    # Création du fichier de configuration Supabase
    mkdir -p src/lib
    
    cat > src/lib/supabase.js << 'EOF'
import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables')
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true
  }
})

// Helper functions pour Oracle Portfolio
export const oraclePortfolioAPI = {
  // Gestion des profils
  async getProfile(userId) {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .single()
    
    if (error) throw error
    return data
  },

  // Gestion des portefeuilles
  async getPortfolios(userId) {
    const { data, error } = await supabase
      .from('portfolios')
      .select(`
        *,
        portfolio_positions (
          *,
          assets (*)
        )
      `)
      .eq('user_id', userId)
    
    if (error) throw error
    return data
  },

  // Analyses de régimes économiques
  async getEconomicRegimes(country, limit = 10) {
    const { data, error } = await supabase
      .from('economic_regimes')
      .select('*')
      .eq('country', country)
      .order('analysis_date', { ascending: false })
      .limit(limit)
    
    if (error) throw error
    return data
  },

  // Sauvegarde d'analyse de régime
  async saveEconomicRegime(regimeData) {
    const { data, error } = await supabase
      .from('economic_regimes')
      .upsert(regimeData)
      .select()
    
    if (error) throw error
    return data
  },

  // Gestion des backtests
  async getBacktests(userId) {
    const { data, error } = await supabase
      .from('backtests')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
    
    if (error) throw error
    return data
  },

  async saveBacktest(backtestData) {
    const { data, error } = await supabase
      .from('backtests')
      .insert(backtestData)
      .select()
    
    if (error) throw error
    return data
  },

  // Analyses de performance
  async getPerformanceAnalyses(portfolioId) {
    const { data, error } = await supabase
      .from('performance_analyses')
      .select('*')
      .eq('portfolio_id', portfolioId)
      .order('analysis_date', { ascending: false })
    
    if (error) throw error
    return data
  },

  async savePerformanceAnalysis(analysisData) {
    const { data, error } = await supabase
      .from('performance_analyses')
      .upsert(analysisData)
      .select()
    
    if (error) throw error
    return data
  },

  // Logs d'activité
  async logActivity(userId, action, entityType, entityId, details) {
    const { error } = await supabase
      .from('activity_logs')
      .insert({
        user_id: userId,
        action,
        entity_type: entityType,
        entity_id: entityId,
        details
      })
    
    if (error) throw error
  }
}
EOF
    
    log_info "✅ Configuration Supabase créée"
}

# Affichage des instructions
show_setup_instructions() {
    echo ""
    echo "🎉 CONFIGURATION SUPABASE TERMINÉE"
    echo "=================================="
    echo ""
    echo "📋 Prochaines étapes:"
    echo ""
    echo "1. 🌐 Créer un projet Supabase:"
    echo "   - Aller sur https://supabase.com"
    echo "   - Créer un nouveau projet"
    echo "   - Noter l'URL et les clés API"
    echo ""
    echo "2. 🔧 Configurer les variables d'environnement:"
    echo "   - Éditer le fichier .env"
    echo "   - Remplacer les valeurs Supabase par les vraies"
    echo ""
    echo "3. 🗄️ Appliquer les migrations:"
    echo "   supabase db push"
    echo ""
    echo "4. 🚀 Démarrer le développement local:"
    echo "   supabase start"
    echo "   npm run dev"
    echo ""
    echo "📁 Fichiers créés:"
    echo "   - supabase/migrations/xxx_oracle_portfolio_schema.sql"
    echo "   - src/lib/supabase.js"
    echo "   - Variables ajoutées à .env"
    echo ""
    echo "🔗 Documentation:"
    echo "   - Supabase: https://supabase.com/docs"
    echo "   - Auth: https://supabase.com/docs/guides/auth"
    echo "   - Database: https://supabase.com/docs/guides/database"
}

# Fonction principale
main() {
    log_info "Début de la configuration Supabase..."
    
    check_prerequisites
    install_supabase_cli
    init_supabase_project
    setup_database_schema
    setup_environment_variables
    install_supabase_dependencies
    create_supabase_config
    show_setup_instructions
    
    log_info "🚀 Configuration Supabase terminée!"
}

# Gestion des erreurs
trap 'log_error "Erreur lors de la configuration Supabase."; exit 1' ERR

# Exécution
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi

